﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using DAL;
using System.Data.SqlTypes;

namespace BAL.Order
{
  public class OrderEntryBAL
    {
      public int InsertOrderEntry(Int64  VisId,string OrdDocId,int UserId,string  VDate,int  SMId,int PartyId,int AreaId,string Remarks,decimal OrderAmount)
      {
          DbParameter[] dbParam = new DbParameter[13];


          dbParam[0] = new DbParameter("@OrdId", DbParameter.DbType.Int,4, 0);
          dbParam[1] = new DbParameter("@VisId", DbParameter.DbType.Int,4, VisId);
          dbParam[2] = new DbParameter("@OrdDocId", DbParameter.DbType.VarChar, 30, OrdDocId);
          dbParam[3] = new DbParameter("@UserId", DbParameter.DbType.Int, 4, UserId);
          dbParam[4] = new DbParameter("@PartyId", DbParameter.DbType.Int, 4, PartyId);
          dbParam[5] = new DbParameter("@SMId", DbParameter.DbType.BigInt, 8, SMId);
          dbParam[6] = new DbParameter("@AreaId", DbParameter.DbType.VarChar, 20, AreaId);
          if (VDate == "")
          {
              dbParam[7] = new DbParameter("@VDate", DbParameter.DbType.DateTime, 8, SqlDateTime.Null);
          }
          else
          {
              dbParam[7] = new DbParameter("@VDate", DbParameter.DbType.DateTime, 8, Convert.ToDateTime(VDate));
          }
          dbParam[8] = new DbParameter("@OrderAmount", DbParameter.DbType.VarChar, 20, OrderAmount);
          dbParam[9] = new DbParameter("@OrderStatus", DbParameter.DbType.VarChar, 20, 0);
          
        
          dbParam[10] = new DbParameter("@Remarks", DbParameter.DbType.VarChar, 150, Remarks);
          dbParam[11] = new DbParameter("@Status", DbParameter.DbType.VarChar, 15, "Insert");
          dbParam[12] = new DbParameter("@ReturnVal", DbParameter.DbType.Int,4, ParameterDirection.Output);
          DbConnectionDAL.ExecuteNonQuery(CommandType.StoredProcedure, "udp_Temp_TransOrder_ups", dbParam);
          return Convert.ToInt32(dbParam[12].Value);
      }


      public int UpdateOrderEntry(Int64 OrdId,Int64 VisId,int UserId, string VDate, int SMId, int PartyId, int AreaId, string Remarks, decimal OrderAmount)
      {
          DbParameter[] dbParam = new DbParameter[13];
          dbParam[0] = new DbParameter("@OrdId", DbParameter.DbType.Int, 4, OrdId);
          dbParam[1] = new DbParameter("@VisId", DbParameter.DbType.Int, 4, VisId);
          dbParam[2] = new DbParameter("@OrdDocId", DbParameter.DbType.VarChar, 30, "");
          dbParam[3] = new DbParameter("@UserId", DbParameter.DbType.Int, 4, UserId);
          dbParam[4] = new DbParameter("@PartyId", DbParameter.DbType.Int, 4, PartyId);
          dbParam[5] = new DbParameter("@SMId", DbParameter.DbType.BigInt, 8, SMId);
          dbParam[6] = new DbParameter("@AreaId", DbParameter.DbType.VarChar, 20, AreaId);
          if (VDate == "")
          {
              dbParam[7] = new DbParameter("@VDate", DbParameter.DbType.DateTime, 8, SqlDateTime.Null);
          }
          else
          {
              dbParam[7] = new DbParameter("@VDate", DbParameter.DbType.DateTime, 8, Convert.ToDateTime(VDate));
          }
          dbParam[8] = new DbParameter("@OrderAmount", DbParameter.DbType.VarChar, 20, OrderAmount);
          dbParam[9] = new DbParameter("@OrderStatus", DbParameter.DbType.VarChar, 20, 0);
          dbParam[10] = new DbParameter("@Remarks", DbParameter.DbType.VarChar, 150, Remarks);
          dbParam[11] = new DbParameter("@Status", DbParameter.DbType.VarChar, 15, "Update");
          dbParam[12] = new DbParameter("@ReturnVal", DbParameter.DbType.Int, 4, ParameterDirection.Output);
          DbConnectionDAL.ExecuteNonQuery(CommandType.StoredProcedure, "udp_Temp_TransOrder_ups", dbParam);
          return Convert.ToInt32(dbParam[12].Value);
      }

      public int delete(string OrdId)
      {
          DbParameter[] dbParam = new DbParameter[2];
          dbParam[0] = new DbParameter("@OrdId", DbParameter.DbType.Int, 1, Convert.ToInt32(OrdId));
          dbParam[1] = new DbParameter("@ReturnVal", DbParameter.DbType.Int, 1, ParameterDirection.Output);
          DbConnectionDAL.ExecuteNonQuery(CommandType.StoredProcedure, "udp_Temp_TransOrder_del", dbParam);
          return Convert.ToInt32(dbParam[1].Value);
      }
    }
}
